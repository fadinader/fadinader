/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// API route: Perform AI Privacy Analysis using Gemini
app.post("/api/gemini/analyze", async (req, res) => {
  const { name, description, department, leadName, answers } = req.body;

  if (!name || !description || !answers) {
    return res.status(400).json({ error: "Missing required fields (name, description, answers)" });
  }

  const apiKey = process.env.GEMINI_API_KEY;

  // Graceful handling of missing API key for sandbox resiliency
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    console.warn("Warning: GEMINI_API_KEY is not configured or uses placeholder. Providing high-quality fallback analysis.");
    // Generate a high-quality simulated fallback assessment based on inputs so the app still functions perfectly
    const fallbackAnalysis = generateFallbackAnalysis(name, description, answers);
    return res.json({
      analysis: fallbackAnalysis,
      isDemoMode: true
    });
  }

  try {
    // Lazy initialization of Gemini SDK
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });

    const prompt = `
      Please perform a professional GDPR and EU AI Act compliance assessment for the following AI project in Vodafone:
      
      Project Name: ${name}
      Department: ${department}
      Lead Name: ${leadName}
      Project Description: ${description}
      
      Privacy Assessment Questionnaire Answers:
      - Personal Data Types Collected: ${answers.dataTypes?.join(", ") || "None"}
      - Data Minimization Checklist Checked? ${answers.dataMinimized ? "Yes" : "No"}
      - Data Minimization Explanation: ${answers.dataMinimizationExplanation || "N/A"}
      - Proposed Data Retention Period: ${answers.dataRetentionPeriod || "N/A"}
      - Training Data Source: ${answers.trainingDataSource || "N/A"}
      - Synthetic Data Used? ${answers.syntheticDataUsed ? "Yes" : "No"}
      - Data Bias Checked? ${answers.biasChecked ? "Yes" : "No"}
      - Bias Mitigation Explanation: ${answers.biasMitigationExplanation || "N/A"}
      - Automated Decision Making? ${answers.automatedDecisionMaking ? "Yes" : "No"}
      - Automated Decision Explanation: ${answers.automatedDecisionExplanation || "N/A"}
      - Human Oversight Mechanism: ${answers.humanOversightMechanism || "N/A"}
      - Third Party Vendor Involved? ${answers.thirdPartyVendor ? "Yes" : "No"}
      - Third Party Details: ${answers.thirdPartyDetails || "N/A"}
      - Primary Data Storage Location: ${answers.dataLocation || "N/A"}
      - Cross-Border Transfers? ${answers.crossBorderTransfer ? "Yes" : "No"}
      - Cross-Border Details: ${answers.crossBorderDetails || "N/A"}
      - Generative AI technology used? ${answers.generativeAI ? "Yes" : "No"}
      - GenAI Safety Controls implemented? ${answers.genAIPromptSafety ? "Yes" : "No"}
      - User Opt-Out Available? ${answers.userOptOutAvailable ? "Yes" : "No"}

      Analyze this project based on Vodafone's 5 AI Ethical and Privacy Commitments:
      1. Respect for Privacy and Security (GDPR requirements, Data Minimization, secure storage, DPIA, Legal basis)
      2. Fairness and Non-Discrimination (bias checks, representative training data)
      3. Transparency and Explainability (clarity of decision logic, notifying customers)
      4. Human Oversight and Accountability (human-in-the-loop, review processes)
      5. Safety, Security, and Reliability (prompt safety, data localization)

      Provide a structured evaluation following the requested response schema. Be constructive, professional, and specific to Vodafone's telecom domain (e.g. mention customer traffic logs, customer consent, GDPR Article 6 legal bases, and the EU AI Act categorization).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: `You are a Senior GDPR and EU AI Act Compliance Officer on Vodafone's Privacy Team. 
        Your role is to assess AI projects submitted by Vodafone employees and provide clear, authoritative risk ratings (Low, Medium, High, Critical), 
        identify specific GDPR/EU AI Act risks, list concrete required mitigation recommendations, determine if a Data Protection Impact Assessment (DPIA) is legally required, 
        state the correct legal basis for data processing, and classify the AI system under the EU AI Act (Prohibited, High-Risk, Limited Risk, Minimal Risk).`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: [
            "overallRisk",
            "riskJustification",
            "complianceScore",
            "keyRisks",
            "recommendations",
            "dpiaRequired",
            "dpiaJustification",
            "legalBasis",
            "euAiActClassification"
          ],
          properties: {
            overallRisk: {
              type: Type.STRING,
              enum: ["Low", "Medium", "High", "Critical"],
              description: "The overall privacy risk level determined for this AI project."
            },
            riskJustification: {
              type: Type.STRING,
              description: "A detailed explanation justifying the overall risk level based on GDPR, Vodafone policy, and data handling practices."
            },
            complianceScore: {
              type: Type.INTEGER,
              description: "An overall compliance score from 0 to 100 representing readiness."
            },
            keyRisks: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of key GDPR, bias, security, or regulatory risks identified in the design."
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Specific, actionable compliance steps and mitigations required of the project team."
            },
            dpiaRequired: {
              type: Type.BOOLEAN,
              description: "Whether a formal Data Protection Impact Assessment (DPIA) is legally required under GDPR Article 35."
            },
            dpiaJustification: {
              type: Type.STRING,
              description: "The legal reasoning for why a DPIA is or is not required."
            },
            legalBasis: {
              type: Type.STRING,
              description: "The primary recommended legal basis under GDPR Article 6 (e.g., Consent, Legitimate Interests, Contractual Necessity)."
            },
            euAiActClassification: {
              type: Type.STRING,
              enum: ["Prohibited", "High-Risk", "Limited Risk", "Minimal Risk"],
              description: "The classification of this system under the European Union AI Act."
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from Gemini API");
    }

    const analysis = JSON.parse(text.trim());
    return res.json({ analysis, isDemoMode: false });

  } catch (error) {
    console.error("Gemini analysis error:", error);
    // Provide automated analysis on server side if external API error occurs to preserve UX
    const fallbackAnalysis = generateFallbackAnalysis(name, description, answers);
    return res.json({
      analysis: fallbackAnalysis,
      isDemoMode: true,
      apiError: error instanceof Error ? error.message : "Internal Server Error"
    });
  }
});

// Fallback logic for high resilience in sandbox
function generateFallbackAnalysis(name: string, description: string, answers: any): any {
  let overallRisk: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
  let complianceScore = 95;
  const keyRisks: string[] = [];
  const recommendations: string[] = [];
  let dpiaRequired = false;
  let euAiActClassification: 'Prohibited' | 'High-Risk' | 'Limited Risk' | 'Minimal Risk' = 'Minimal Risk';
  let legalBasis = "Legitimate Interests";

  // Analyze indicators
  const collectPII = answers.dataTypes?.some((t: string) => ["Customer PII", "Location Data", "Traffic/Call Logs", "Biometric", "Financial"].includes(t));
  const sensitivePII = answers.dataTypes?.some((t: string) => ["Biometric", "Financial", "Location Data"].includes(t));
  
  if (collectPII) {
    overallRisk = 'Medium';
    complianceScore = 80;
    keyRisks.push("Collection of customer personal identifiable information (PII) requires strict access controls.");
    recommendations.push("Ensure encryption at rest and in transit for all customer PII.");
    legalBasis = "Consent";
  }

  if (sensitivePII || answers.automatedDecisionMaking) {
    overallRisk = 'High';
    complianceScore = 65;
    dpiaRequired = true;
    euAiActClassification = 'High-Risk';
    
    if (answers.automatedDecisionMaking) {
      keyRisks.push("Automated decision-making without sufficient human oversight could lead to biased outcomes or GDPR Article 22 non-compliance.");
      recommendations.push("Establish a formal Human-in-the-Loop oversight mechanism with documented operator training.");
    }
    if (sensitivePII) {
      keyRisks.push("Processing sensitive categories of telecom data (e.g., precise geolocation or biometric details) triggers automatic high risk.");
      recommendations.push("Implement strict anonymization or pseudonymization techniques at the ingestion layer.");
    }
  }

  if (answers.crossBorderTransfer) {
    if ((overallRisk as string) !== 'Critical' && overallRisk !== 'High') {
      overallRisk = 'High';
    }
    keyRisks.push("Cross-border data transfer outside the EEA/UK introduces compliance risks under GDPR Chapter V.");
    recommendations.push("Draft and sign Standard Contractual Clauses (SCCs) with third-party vendors and conduct a Transfer Impact Assessment (TIA).");
  }

  if (answers.generativeAI && !answers.genAIPromptSafety) {
    overallRisk = 'High';
    keyRisks.push("Generative AI deployment lacking safety guardrails is vulnerable to prompt injection, data leaks, or hallucinated outputs.");
    recommendations.push("Deploy Vodafone-approved GenAI gateway guardrails and system instructions to prevent prompt leak and toxicity.");
  }

  if (!answers.dataMinimized) {
    complianceScore -= 15;
    keyRisks.push("Lack of active data minimization protocol violates core principles of GDPR Article 5(1)(c).");
    recommendations.push("Establish automated purging routines matching the stated retention period.");
  }

  if (!answers.biasChecked && collectPII) {
    complianceScore -= 10;
    keyRisks.push("Algorithmic bias risk has not been formally evaluated or mitigated.");
    recommendations.push("Conduct a demographic fairness review on the training dataset or model outputs before production rollout.");
  }

  return {
    overallRisk,
    riskJustification: `This assessment represents a local compliance review of the AI project '${name}' based on Vodafone Privacy criteria. ${dpiaRequired ? "Processing of sensitive telecom data types or automated workflows necessitates high scrutiny." : "The project demonstrates standard risk characteristics with actionable mitigations."}`,
    complianceScore: Math.max(20, Math.min(100, complianceScore)),
    keyRisks: keyRisks.length > 0 ? keyRisks : ["No high-severity risks detected based on the questionnaire."],
    recommendations: recommendations.length > 0 ? recommendations : ["Maintain regular security audits and review the project annually."],
    dpiaRequired,
    dpiaJustification: dpiaRequired 
      ? "Under GDPR Article 35, processing sensitive data (location, biometrics, or automated decisions) on a large telecom scale presents high risks to individual rights, making a DPIA mandatory."
      : "A formal DPIA is not legally mandated as the project does not involve large-scale sensitive data or automated profiling of individual legal rights.",
    legalBasis,
    euAiActClassification
  };
}

// Vite integration middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Vodafone Privacy Server running on http://localhost:${PORT}`);
  });
}

startServer();
