/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ArrowLeft, ArrowRight, Save, ShieldCheck, Sparkles, Loader2, Info } from "lucide-react";
import { AssessmentAnswers, AIProject } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface AssessmentFormProps {
  onSave: (project: Omit<AIProject, "id" | "createdAt" | "updatedAt" | "status" | "riskRating" | "aiAnalysis" | "reviewerNotes" | "conditions" | "signOffBy" | "signOffDate">) => Promise<void>;
  onCancel: () => void;
  isSubmitting: boolean;
}

const INITIAL_ANSWERS: AssessmentAnswers = {
  dataTypes: [],
  dataMinimized: false,
  dataMinimizationExplanation: "",
  dataRetentionPeriod: "30 days",
  trainingDataSource: "Internal proprietary",
  syntheticDataUsed: false,
  biasChecked: false,
  biasMitigationExplanation: "",
  automatedDecisionMaking: false,
  automatedDecisionExplanation: "",
  humanOversightMechanism: "",
  thirdPartyVendor: false,
  thirdPartyDetails: "",
  dataLocation: "EU",
  crossBorderTransfer: false,
  crossBorderDetails: "",
  generativeAI: false,
  genAIPromptSafety: false,
  userOptOutAvailable: false
};

const DATA_TYPES = [
  "Customer PII (Name, Email, Address)",
  "Traffic/Call Logs (IPs, call events)",
  "Location Data (Precise GPS, Cell tower IDs)",
  "Employee Data (HR records, resumes)",
  "Biometric Data (Voice, facial recognition)",
  "Financial Data (Billing details, credit card)",
  "Public/Non-personal (Technical metrics, telemetry)"
];

const DEPARTMENTS = [
  "Customer Operations",
  "Network & Technology",
  "Marketing & Sales",
  "Human Resources",
  "Finance & Treasury",
  "Legal & Corporate Affairs"
];

const DATA_LOCATIONS = ["EU", "UK", "US", "Global", "Other"];

export default function AssessmentForm({ onSave, onCancel, isSubmitting }: AssessmentFormProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [department, setDepartment] = useState(DEPARTMENTS[0]);
  const [leadName, setLeadName] = useState("");
  const [leadEmail, setLeadEmail] = useState("");
  const [answers, setAnswers] = useState<AssessmentAnswers>(INITIAL_ANSWERS);
  const [validationError, setValidationError] = useState("");

  const handleDataTypeToggle = (type: string) => {
    setAnswers(prev => {
      const dataTypes = prev.dataTypes.includes(type)
        ? prev.dataTypes.filter(t => t !== type)
        : [...prev.dataTypes, type];
      return { ...prev, dataTypes };
    });
  };

  const handleAnswerChange = <K extends keyof AssessmentAnswers>(key: K, value: AssessmentAnswers[K]) => {
    setAnswers(prev => ({ ...prev, [key]: value }));
  };

  const validateStep = (step: number): boolean => {
    setValidationError("");
    if (step === 1) {
      if (!name.trim()) {
        setValidationError("Project Name is required.");
        return false;
      }
      if (!description.trim()) {
        setValidationError("Project Description is required.");
        return false;
      }
      if (description.length < 30) {
        setValidationError("Please describe the AI project in more detail (minimum 30 characters).");
        return false;
      }
      if (!leadName.trim()) {
        setValidationError("Project Lead Name is required.");
        return false;
      }
      if (!leadEmail.trim() || !leadEmail.includes("@")) {
        setValidationError("A valid corporate email address is required.");
        return false;
      }
    }
    if (step === 2) {
      if (answers.dataTypes.length === 0) {
        setValidationError("Please select at least one type of data collected/processed.");
        return false;
      }
      if (answers.dataMinimized && !answers.dataMinimizationExplanation.trim()) {
        setValidationError("Please explain your data minimization process.");
        return false;
      }
    }
    if (step === 3) {
      if (answers.biasChecked && !answers.biasMitigationExplanation.trim()) {
        setValidationError("Please explain how data bias is being checked or mitigated.");
        return false;
      }
    }
    if (step === 4) {
      if (answers.thirdPartyVendor && !answers.thirdPartyDetails.trim()) {
        setValidationError("Please provide details about the third-party vendor.");
        return false;
      }
      if (answers.crossBorderTransfer && !answers.crossBorderDetails.trim()) {
        setValidationError("Please specify standard contractual clauses (SCCs) or legal grounds for transfer.");
        return false;
      }
    }
    return true;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    setValidationError("");
    setCurrentStep(prev => prev - 1);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep(currentStep)) return;

    await onSave({
      name,
      description,
      department,
      leadName,
      leadEmail,
      answers
    });
  };

  return (
    <div id="assessment-form-container" className="max-w-3xl mx-auto bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
      {/* Top Progress bar and branding */}
      <div id="form-header" className="bg-gradient-to-r from-red-600 to-red-700 px-8 py-6 text-white flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">New Privacy Assessment</h2>
          <p className="text-xs text-red-100 mt-1">Vodafone Privacy & AI Ethical Standard Compliance</p>
        </div>
        <div className="flex items-center gap-2 bg-red-800/40 px-3 py-1.5 rounded-lg border border-red-500/30">
          <ShieldCheck className="h-4.5 w-4.5 text-red-200" />
          <span className="text-xs font-semibold text-red-100">Step {currentStep} of 5</span>
        </div>
      </div>

      {/* Steps Visual Indicator */}
      <div id="steps-indicator" className="px-8 py-4 bg-gray-50 border-b border-gray-100 flex items-center justify-between gap-1">
        {[
          { label: "Overview", step: 1 },
          { label: "Data Scope", step: 2 },
          { label: "Ethics & Bias", step: 3 },
          { label: "Infrastructure", step: 4 },
          { label: "Generative AI", step: 5 }
        ].map(s => (
          <div key={s.step} className="flex-1 flex flex-col items-center gap-1.5">
            <div
              className={`h-2 w-full rounded-full transition-colors duration-200 ${
                currentStep >= s.step ? "bg-red-600" : "bg-gray-200"
              }`}
            />
            <span className={`text-[10px] font-bold uppercase ${
              currentStep === s.step ? "text-red-600" : "text-gray-400"
            }`}>
              {s.label}
            </span>
          </div>
        ))}
      </div>

      {/* Form Content */}
      <form id="assessment-multi-step-form" onSubmit={handleSubmit} className="p-8 space-y-6">
        <AnimatePresence mode="wait">
          {validationError && (
            <motion.div
              id="form-error-banner"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="bg-red-50 border border-red-100 text-red-700 px-4 py-3 rounded-lg text-xs font-medium flex items-start gap-2"
            >
              <Info className="h-4 w-4 shrink-0 text-red-500 mt-0.5" />
              <span>{validationError}</span>
            </motion.div>
          )}

          {/* STEP 1: PROJECT OVERVIEW */}
          {currentStep === 1 && (
            <motion.div
              key="step-1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="border-b border-gray-100 pb-2">
                <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Step 1: General Information</h3>
                <p className="text-xs text-gray-500">Provide high-level details of the AI system being deployed.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label htmlFor="project-name" className="text-xs font-semibold text-gray-700">Project Name *</label>
                  <input
                    id="project-name"
                    type="text"
                    required
                    placeholder="e.g., TOBI Customer Support Upgrade"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors"
                  />
                </div>
                <div className="space-y-1">
                  <label htmlFor="project-dept" className="text-xs font-semibold text-gray-700">Vodafone Department *</label>
                  <select
                    id="project-dept"
                    value={department}
                    onChange={e => setDepartment(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-200 bg-white focus:outline-hidden focus:border-red-500 transition-colors"
                  >
                    {DEPARTMENTS.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="project-desc" className="text-xs font-semibold text-gray-700">Project Description *</label>
                <textarea
                  id="project-desc"
                  rows={4}
                  required
                  placeholder="Describe what the AI system does, its business goal, inputs, logic parameters, and user-facing outputs..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors leading-relaxed"
                />
                <span className="text-[10px] text-gray-400">Be descriptive; the AI Privacy Consultant analyzes this text to extract risk parameters.</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label htmlFor="lead-name" className="text-xs font-semibold text-gray-700">Project Owner Name *</label>
                  <input
                    id="lead-name"
                    type="text"
                    required
                    placeholder="Sarah Jenkins"
                    value={leadName}
                    onChange={e => setLeadName(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors"
                  />
                </div>
                <div className="space-y-1">
                  <label htmlFor="lead-email" className="text-xs font-semibold text-gray-700">Project Owner Corporate Email *</label>
                  <input
                    id="lead-email"
                    type="email"
                    required
                    placeholder="sarah.jenkins@vodafone.com"
                    value={leadEmail}
                    onChange={e => setLeadEmail(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 2: DATA & MINIMIZATION */}
          {currentStep === 2 && (
            <motion.div
              key="step-2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="border-b border-gray-100 pb-2">
                <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Step 2: Data Scope & Minimization</h3>
                <p className="text-xs text-gray-500">Analyze categories of data processed by the AI system.</p>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-gray-700 block">Personal Data Categories Processed *</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {DATA_TYPES.map(type => (
                    <button
                      id={`btn-toggle-type-${type.replace(/\s+/g, '-').toLowerCase()}`}
                      key={type}
                      type="button"
                      onClick={() => handleDataTypeToggle(type)}
                      className={`text-left text-xs px-4 py-3 rounded-xl border flex items-center justify-between transition-colors cursor-pointer ${
                        answers.dataTypes.includes(type)
                          ? "bg-red-50 border-red-300 text-red-900 font-medium"
                          : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      <span>{type}</span>
                      <div className={`h-4 w-4 rounded-full border flex items-center justify-center shrink-0 ${
                        answers.dataTypes.includes(type) ? "border-red-600 bg-red-600 text-white" : "border-gray-300 bg-white"
                      }`}>
                        {answers.dataTypes.includes(type) && (
                          <div className="h-1.5 w-1.5 rounded-full bg-white" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-gray-700 block">Active Data Minimization Checklist?</span>
                  <div className="flex gap-4">
                    <button
                      id="btn-minimization-yes"
                      type="button"
                      onClick={() => handleAnswerChange("dataMinimized", true)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        answers.dataMinimized ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      Yes
                    </button>
                    <button
                      id="btn-minimization-no"
                      type="button"
                      onClick={() => handleAnswerChange("dataMinimized", false)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        !answers.dataMinimized ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      No
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <label htmlFor="data-retention" className="text-xs font-semibold text-gray-700">Data Retention Period</label>
                  <input
                    id="data-retention"
                    type="text"
                    placeholder="e.g. 90 days, 1 year, or Purged instantly"
                    value={answers.dataRetentionPeriod}
                    onChange={e => handleAnswerChange("dataRetentionPeriod", e.target.value)}
                    className="w-full text-xs px-3.5 py-2 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors"
                  />
                </div>
              </div>

              {answers.dataMinimized && (
                <div className="space-y-1">
                  <label htmlFor="minimization-explanation" className="text-xs font-semibold text-gray-700">Minimization Explanation *</label>
                  <textarea
                    id="minimization-explanation"
                    rows={2}
                    placeholder="Describe what filtering, masking, or aggregation is applied to ensure only the absolute minimum required personal data is ingested."
                    value={answers.dataMinimizationExplanation}
                    onChange={e => handleAnswerChange("dataMinimizationExplanation", e.target.value)}
                    className="w-full text-xs px-3.5 py-2 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors"
                  />
                </div>
              )}
            </motion.div>
          )}

          {/* STEP 3: ETHICS & BIAS */}
          {currentStep === 3 && (
            <motion.div
              key="step-3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="border-b border-gray-100 pb-2">
                <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Step 3: Algorithmic Fairness & Bias</h3>
                <p className="text-xs text-gray-500">Establish mechanisms to prevent discriminatory algorithms.</p>
              </div>

              <div className="space-y-1">
                <label htmlFor="training-source" className="text-xs font-semibold text-gray-700">Primary Dataset or Model Training Source</label>
                <select
                  id="training-source"
                  value={answers.trainingDataSource}
                  onChange={e => handleAnswerChange("trainingDataSource", e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-200 bg-white focus:outline-hidden"
                >
                  <option value="Internal proprietary database">Internal proprietary database</option>
                  <option value="Public internet scrape / open-source">Public internet scrape / open-source</option>
                  <option value="Licensed third-party datasets">Licensed third-party datasets</option>
                  <option value="Synthetic datasets">Synthetic datasets</option>
                  <option value="Pre-trained commercial APIs (e.g. OpenAI, Anthropic)">Pre-trained commercial APIs (e.g. OpenAI, Anthropic)</option>
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-gray-700 block">Has Algorithmic Bias Been Evaluated?</span>
                  <div className="flex gap-4">
                    <button
                      id="btn-bias-yes"
                      type="button"
                      onClick={() => handleAnswerChange("biasChecked", true)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        answers.biasChecked ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      Yes
                    </button>
                    <button
                      id="btn-bias-no"
                      type="button"
                      onClick={() => handleAnswerChange("biasChecked", false)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        !answers.biasChecked ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      No
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="Is Synthetic Data Used? block text-xs font-semibold text-gray-700">Is Synthetic Data Utilized?</span>
                  <div className="flex gap-4">
                    <button
                      id="btn-synthetic-yes"
                      type="button"
                      onClick={() => handleAnswerChange("syntheticDataUsed", true)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        answers.syntheticDataUsed ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      Yes
                    </button>
                    <button
                      id="btn-synthetic-no"
                      type="button"
                      onClick={() => handleAnswerChange("syntheticDataUsed", false)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        !answers.syntheticDataUsed ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      No
                    </button>
                  </div>
                </div>
              </div>

              {answers.biasChecked && (
                <div className="space-y-1">
                  <label htmlFor="bias-explanation" className="text-xs font-semibold text-gray-700">Bias Evaluation or Mitigation Process *</label>
                  <textarea
                    id="bias-explanation"
                    rows={2}
                    placeholder="Describe how data demographic balance is audited, or what safeguards prevent demographic-based discrimination in the decision logic."
                    value={answers.biasMitigationExplanation}
                    onChange={e => handleAnswerChange("biasMitigationExplanation", e.target.value)}
                    className="w-full text-xs px-3.5 py-2 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors"
                  />
                </div>
              )}
            </motion.div>
          )}

          {/* STEP 4: INFRASTRUCTURE & VENDORS */}
          {currentStep === 4 && (
            <motion.div
              key="step-4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="border-b border-gray-100 pb-2">
                <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Step 4: Infrastructure & Third Parties</h3>
                <p className="text-xs text-gray-500">Address third-party risk, storage locations, and global transfers.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-gray-700 block">Is a Third-Party Vendor Involved?</span>
                  <div className="flex gap-4">
                    <button
                      id="btn-vendor-yes"
                      type="button"
                      onClick={() => handleAnswerChange("thirdPartyVendor", true)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        answers.thirdPartyVendor ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      Yes
                    </button>
                    <button
                      id="btn-vendor-no"
                      type="button"
                      onClick={() => handleAnswerChange("thirdPartyVendor", false)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        !answers.thirdPartyVendor ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      No
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <label htmlFor="data-location" className="text-xs font-semibold text-gray-700">Primary Data Hosting Region</label>
                  <select
                    id="data-location"
                    value={answers.dataLocation}
                    onChange={e => handleAnswerChange("dataLocation", e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-200 bg-white focus:outline-hidden"
                  >
                    {DATA_LOCATIONS.map(loc => (
                      <option key={loc} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>
              </div>

              {answers.thirdPartyVendor && (
                <div className="space-y-1">
                  <label htmlFor="vendor-details" className="text-xs font-semibold text-gray-700">Third-Party Vendor Details *</label>
                  <input
                    id="vendor-details"
                    type="text"
                    placeholder="e.g. Workday Recruiting Cloud, Google Cloud Vertex Suite"
                    value={answers.thirdPartyDetails}
                    onChange={e => handleAnswerChange("thirdPartyDetails", e.target.value)}
                    className="w-full text-xs px-3.5 py-2 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors"
                  />
                </div>
              )}

              <div className="space-y-2">
                <span className="text-xs font-semibold text-gray-700 block">Does processing involve Cross-Border Data Transfer?</span>
                <div className="flex gap-4">
                  <button
                    id="btn-crossborder-yes"
                    type="button"
                    onClick={() => handleAnswerChange("crossBorderTransfer", true)}
                    className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                      answers.crossBorderTransfer ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                    }`}
                  >
                    Yes
                  </button>
                  <button
                    id="btn-crossborder-no"
                    type="button"
                    onClick={() => handleAnswerChange("crossBorderTransfer", false)}
                    className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                      !answers.crossBorderTransfer ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                    }`}
                  >
                    No
                  </button>
                </div>
              </div>

              {answers.crossBorderTransfer && (
                <div className="space-y-1">
                  <label htmlFor="crossborder-details" className="text-xs font-semibold text-gray-700">Transfer Safeguards details *</label>
                  <textarea
                    id="crossborder-details"
                    rows={2}
                    placeholder="Specify safeguards (e.g. European Commission Standard Contractual Clauses, binding corporate rules, EU-US Data Privacy Framework)..."
                    value={answers.crossBorderDetails}
                    onChange={e => handleAnswerChange("crossBorderDetails", e.target.value)}
                    className="w-full text-xs px-3.5 py-2 rounded-lg border border-gray-200 focus:outline-hidden"
                  />
                </div>
              )}
            </motion.div>
          )}

          {/* STEP 5: GENERATIVE AI */}
          {currentStep === 5 && (
            <motion.div
              key="step-5"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="border-b border-gray-100 pb-2">
                <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Step 5: Generative AI & Automation</h3>
                <p className="text-xs text-gray-500">Review prompt safety, customer options, and automated profiling.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-gray-700 block">Does the project utilize Generative AI?</span>
                  <div className="flex gap-4">
                    <button
                      id="btn-genai-yes"
                      type="button"
                      onClick={() => handleAnswerChange("generativeAI", true)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        answers.generativeAI ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      Yes
                    </button>
                    <button
                      id="btn-genai-no"
                      type="button"
                      onClick={() => handleAnswerChange("generativeAI", false)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        !answers.generativeAI ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      No
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-semibold text-gray-700 block">Are Automated Decisions Made?</span>
                  <div className="flex gap-4">
                    <button
                      id="btn-automated-yes"
                      type="button"
                      onClick={() => handleAnswerChange("automatedDecisionMaking", true)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        answers.automatedDecisionMaking ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      Yes
                    </button>
                    <button
                      id="btn-automated-no"
                      type="button"
                      onClick={() => handleAnswerChange("automatedDecisionMaking", false)}
                      className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                        !answers.automatedDecisionMaking ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      No
                    </button>
                  </div>
                </div>
              </div>

              {answers.automatedDecisionMaking && (
                <div className="space-y-1">
                  <label htmlFor="automated-explanation" className="text-xs font-semibold text-gray-700">Automated Decision Logic & Explanation *</label>
                  <textarea
                    id="automated-explanation"
                    rows={2}
                    placeholder="Describe how the decision model operates. Are customers rejected automatically? How can they appeal? (GDPR Article 22 Compliance)..."
                    value={answers.automatedDecisionExplanation}
                    onChange={e => handleAnswerChange("automatedDecisionExplanation", e.target.value)}
                    className="w-full text-xs px-3.5 py-2 rounded-lg border border-gray-200 focus:outline-hidden"
                  />
                </div>
              )}

              <div className="space-y-1">
                <label htmlFor="human-oversight" className="text-xs font-semibold text-gray-700">Human Oversight Mechanism *</label>
                <input
                  id="human-oversight"
                  type="text"
                  placeholder="e.g., Manual recruiter audit, operator review queue, supervisor override..."
                  value={answers.humanOversightMechanism}
                  onChange={e => handleAnswerChange("humanOversightMechanism", e.target.value)}
                  className="w-full text-xs px-3.5 py-2 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500"
                />
              </div>

              {answers.generativeAI && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="space-y-2">
                    <span className="text-xs font-semibold text-gray-700 block">Prompt Guardrails Active?</span>
                    <div className="flex gap-4">
                      <button
                        id="btn-safety-yes"
                        type="button"
                        onClick={() => handleAnswerChange("genAIPromptSafety", true)}
                        className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                          answers.genAIPromptSafety ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                        }`}
                      >
                        Yes
                      </button>
                      <button
                        id="btn-safety-no"
                        type="button"
                        onClick={() => handleAnswerChange("genAIPromptSafety", false)}
                        className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                          !answers.genAIPromptSafety ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                        }`}
                      >
                        No
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-xs font-semibold text-gray-700 block">Is User Opt-Out Available?</span>
                    <div className="flex gap-4">
                      <button
                        id="btn-optout-yes"
                        type="button"
                        onClick={() => handleAnswerChange("userOptOutAvailable", true)}
                        className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                          answers.userOptOutAvailable ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                        }`}
                      >
                        Yes
                      </button>
                      <button
                        id="btn-optout-no"
                        type="button"
                        onClick={() => handleAnswerChange("userOptOutAvailable", false)}
                        className={`flex-1 text-xs py-2 rounded-lg border text-center font-semibold cursor-pointer ${
                          !answers.userOptOutAvailable ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                        }`}
                      >
                        No
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Buttons / Navigation controls */}
        <div id="form-controls" className="pt-6 border-t border-gray-100 flex items-center justify-between gap-4">
          <button
            id="btn-form-cancel"
            type="button"
            onClick={onCancel}
            disabled={isSubmitting}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg border border-gray-200 text-xs font-semibold text-gray-600 hover:bg-gray-50 disabled:opacity-50 cursor-pointer transition-colors"
          >
            Cancel
          </button>

          <div id="nav-actions" className="flex items-center gap-2">
            {currentStep > 1 && (
              <button
                id="btn-form-prev"
                type="button"
                onClick={prevStep}
                disabled={isSubmitting}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg border border-gray-200 text-xs font-semibold text-gray-600 hover:bg-gray-50 disabled:opacity-50 cursor-pointer transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back</span>
              </button>
            )}

            {currentStep < 5 ? (
              <button
                id="btn-form-next"
                type="button"
                onClick={nextStep}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg bg-gray-900 hover:bg-gray-800 text-xs font-semibold text-white cursor-pointer transition-colors"
              >
                <span>Continue</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                id="btn-form-submit"
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-xs font-bold text-white cursor-pointer shadow-sm hover:shadow-md transition-all disabled:opacity-75"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Analyzing Risks...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    <span>Generate AI Compliance Review</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}
