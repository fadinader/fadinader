/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Search, Filter, Plus, Shield, CheckCircle, AlertTriangle, AlertOctagon, 
  ChevronRight, Building, User, BookOpen, Clock, Sparkles 
} from "lucide-react";
import { AIProject, ProjectStatus, RiskLevel } from "../types";
import { motion } from "motion/react";

interface DashboardProps {
  projects: AIProject[];
  onSelectProject: (project: AIProject) => void;
  onNewAssessment: () => void;
  onViewPrinciples: () => void;
}

export default function Dashboard({ projects, onSelectProject, onNewAssessment, onViewPrinciples }: DashboardProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [deptFilter, setDeptFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [riskFilter, setRiskFilter] = useState("All");

  // Summary Metrics calculation
  const totalProjects = projects.length;
  const pendingReview = projects.filter(p => p.status === "In Review" || p.status === "Submitted").length;
  const approvedCount = projects.filter(p => p.status === "Approved" || p.status === "Approved with Conditions").length;
  const dpiaMandatory = projects.filter(p => p.aiAnalysis?.dpiaRequired).length;

  const getRiskColor = (risk: RiskLevel) => {
    switch (risk) {
      case "Critical":
        return "text-purple-600 bg-purple-50 border-purple-100";
      case "High":
        return "text-red-600 bg-red-50 border-red-100";
      case "Medium":
        return "text-orange-600 bg-orange-50 border-orange-100";
      case "Low":
        return "text-green-600 bg-green-50 border-green-100";
      default:
        return "text-gray-500 bg-gray-50 border-gray-100";
    }
  };

  const getStatusStyle = (status: ProjectStatus) => {
    switch (status) {
      case "Approved":
        return "bg-green-100 text-green-800 border-green-200";
      case "Approved with Conditions":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "In Review":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "Rejected":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  // Unique departments for filtering
  const departments = ["All", ...new Set(projects.map(p => p.department))];

  // Filtering logic
  const filteredProjects = projects.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.leadName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = deptFilter === "All" || p.department === deptFilter;
    const matchesStatus = statusFilter === "All" || p.status === statusFilter;
    const matchesRisk = riskFilter === "All" || p.riskRating === riskFilter;

    return matchesSearch && matchesDept && matchesStatus && matchesRisk;
  });

  return (
    <div id="dashboard-container" className="space-y-8">
      {/* Top Welcome Banner with Red accent styling */}
      <div id="dashboard-welcome" className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-6 text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-xs border border-gray-800">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="bg-red-600 text-white text-[10px] font-black tracking-widest px-2 py-0.5 rounded uppercase">VODAFONE AI REGULATORY HUB</span>
            <span className="h-4 w-px bg-gray-700" />
            <span className="text-xs font-semibold text-gray-400">Security & GDPR Ledger</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight">Privacy Officer Assessment Workspace</h1>
          <p className="text-xs text-gray-400 max-w-xl">
            Evaluate, track, and audit artificial intelligence projects across Vodafone's European and UK markets against GDPR guidelines and the EU AI Act framework.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            id="btn-view-ethics-guide"
            onClick={onViewPrinciples}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg border border-gray-700 text-xs font-bold text-gray-200 hover:bg-gray-800 cursor-pointer transition-colors"
          >
            <BookOpen className="h-4 w-4" />
            <span>AI Ethics Guide</span>
          </button>

          <button
            id="btn-trigger-new-assessment"
            onClick={onNewAssessment}
            className="inline-flex items-center gap-1.5 px-4.5 py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-xs font-bold text-white cursor-pointer shadow-sm hover:shadow-md transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Submit AI Project</span>
          </button>
        </div>
      </div>

      {/* Analytics Bento Cards */}
      <div id="analytics-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white border border-gray-100 rounded-xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total Ingested</span>
            <p className="text-2xl font-black text-gray-900">{totalProjects}</p>
            <span className="text-[10px] text-gray-500">Registered AI Projects</span>
          </div>
          <div className="h-10 w-10 rounded-lg bg-red-50 text-red-600 flex items-center justify-center font-bold">
            v
          </div>
        </div>

        <div className="bg-white border border-gray-100 rounded-xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Under Review</span>
            <p className="text-2xl font-black text-blue-600">{pendingReview}</p>
            <span className="text-[10px] text-gray-500">Awaiting Sign-Off Decision</span>
          </div>
          <div className="h-10 w-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <Clock className="h-5 w-5" />
          </div>
        </div>

        <div className="bg-white border border-gray-100 rounded-xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Approved Rollouts</span>
            <p className="text-2xl font-black text-green-600">{approvedCount}</p>
            <span className="text-[10px] text-gray-500">Compliant Implementations</span>
          </div>
          <div className="h-10 w-10 rounded-lg bg-green-50 text-green-600 flex items-center justify-center">
            <CheckCircle className="h-5 w-5" />
          </div>
        </div>

        <div className="bg-white border border-gray-100 rounded-xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">DPIA Mandated</span>
            <p className="text-2xl font-black text-red-600">{dpiaMandatory}</p>
            <span className="text-[10px] text-gray-500">DPIAs Legally Triggered</span>
          </div>
          <div className="h-10 w-10 rounded-lg bg-red-50 text-red-600 flex items-center justify-center">
            <Shield className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* Interactive Controls & Filters */}
      <div id="controls-section" className="bg-white border border-gray-100 rounded-xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              id="search-projects"
              type="text"
              placeholder="Search projects, owners, departments..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 focus:outline-hidden focus:border-red-500 transition-colors"
            />
          </div>

          <div className="flex items-center gap-1 text-xs text-gray-500 shrink-0">
            <Filter className="h-4 w-4 text-gray-400" />
            <span>Active Filter Overlays</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="space-y-1">
            <label htmlFor="filter-department" className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Department</label>
            <select
              id="filter-department"
              value={deptFilter}
              onChange={e => setDeptFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden focus:border-red-500"
            >
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="filter-risk" className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Risk Level</label>
            <select
              id="filter-risk"
              value={riskFilter}
              onChange={e => setRiskFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden"
            >
              <option value="All">All Risks</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
              <option value="Unassessed">Unassessed</option>
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="filter-status" className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Assessment Status</label>
            <select
              id="filter-status"
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden"
            >
              <option value="All">All Statuses</option>
              <option value="In Review">In Review</option>
              <option value="Approved">Approved</option>
              <option value="Approved with Conditions">Approved with Conditions</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main projects grid */}
      <div id="projects-listing-section" className="space-y-4">
        <div className="flex items-center justify-between border-b border-gray-100 pb-2">
          <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider">Registered AI Registry ({filteredProjects.length})</h2>
          <span className="text-[11px] text-gray-400">Click any card to perform audit or review dossier</span>
        </div>

        {filteredProjects.length > 0 ? (
          <div id="filtered-projects-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredProjects.map((project, index) => (
              <motion.div
                id={`project-card-${project.id}`}
                key={project.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25, delay: index * 0.03 }}
                onClick={() => onSelectProject(project)}
                className="bg-white border border-gray-100 rounded-xl p-5 hover:border-red-500 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between space-y-4 group"
              >
                <div className="space-y-3">
                  {/* Category and Department */}
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-gray-400 uppercase">
                      <Building className="h-3.5 w-3.5" /> {project.department}
                    </span>
                    <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-semibold border ${getStatusStyle(project.status)}`}>
                      {project.status}
                    </span>
                  </div>

                  {/* Project Name & Description */}
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-gray-900 group-hover:text-red-600 transition-colors line-clamp-1">{project.name}</h3>
                    <p className="text-xs text-gray-500 line-clamp-3 leading-relaxed">{project.description}</p>
                  </div>
                </div>

                <div className="pt-3 border-t border-gray-50 flex items-center justify-between gap-4">
                  {/* Risks indicator */}
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${getRiskColor(project.riskRating)}`}>
                      {project.riskRating} Risk
                    </span>
                    {project.aiAnalysis?.dpiaRequired && (
                      <span className="text-[9px] font-bold text-red-600 uppercase tracking-wider">DPIA Required</span>
                    )}
                  </div>

                  <span className="inline-flex items-center text-xs font-semibold text-red-600 gap-0.5 group-hover:translate-x-1 transition-transform">
                    <span>Audit</span>
                    <ChevronRight className="h-3.5 w-3.5" />
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div id="empty-state" className="text-center py-12 bg-white border border-gray-100 rounded-xl space-y-3 p-6 shadow-xs">
            <Shield className="h-10 w-10 text-gray-300 mx-auto" />
            <h3 className="text-sm font-bold text-gray-700">No AI Projects Found</h3>
            <p className="text-xs text-gray-500 max-w-md mx-auto">
              No registration dossiers match your search queries or active filter parameters. Adjust your controls or register a new assessment dossier.
            </p>
            <button
              id="btn-empty-trigger-new"
              onClick={onNewAssessment}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-gray-900 hover:bg-gray-800 text-xs font-bold text-white rounded-lg cursor-pointer transition-colors"
            >
              Register First AI Project
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
