/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Shield, Scale, Eye, UserCheck, Activity, CheckCircle2, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

const principles = [
  {
    id: "p1",
    title: "Respect for Privacy & Security",
    icon: Shield,
    color: "bg-red-50 text-red-600 border-red-100",
    description: "AI systems must be designed to fully protect customer and employee data privacy. We employ absolute 'privacy-by-design' methodologies, ensuring rigorous encryption, local hosting, and aggressive data minimization.",
    gdprLinks: ["Article 5(1)(c) - Data Minimization", "Article 25 - Privacy by Design", "Article 32 - Security of Processing"],
    practicalTips: [
      "Avoid feeding raw customer identifiers (MSISDN, IMEI, names) into model prompts or training loops.",
      "Anonymize, pseudonymize, or mask PII at the data ingestion layer.",
      "Never store model caches or telemetry logs indefinitely — establish automatic purging schedules."
    ]
  },
  {
    id: "p2",
    title: "Fairness & Non-Discrimination",
    icon: Scale,
    color: "bg-orange-50 text-orange-600 border-orange-100",
    description: "We are committed to preventing algorithmic bias. AI models must not propagate, amplify, or create discriminatory outcomes based on gender, race, age, location, or socioeconomic status.",
    gdprLinks: ["Article 5(1)(a) - Fairness and Lawfulness", "EU AI Act Article 10 - Data and Data Governance"],
    practicalTips: [
      "Audit training datasets for historical bias and underrepresented groups.",
      "Mask sensitive demographic features during training unless explicitly required for bias mitigation.",
      "Conduct regular performance audits across different sub-populations to identify unequal accuracy rates."
    ]
  },
  {
    id: "p3",
    title: "Transparency & Explainability",
    icon: Eye,
    color: "bg-blue-50 text-blue-600 border-blue-100",
    description: "AI decisions must not be 'black boxes.' Customers and employees have a right to know when they are interacting with an AI system and to receive clear explanations about how decisions are generated.",
    gdprLinks: ["Article 13/14 - Right to Information", "Article 22 - Automated Decision Explanation"],
    practicalTips: [
      "Display highly visible disclaimers on all chat, voice, and web interfaces featuring AI.",
      "For scoring models (e.g., credit check, churn risk), document key decision features in a plain-language registry.",
      "Provide step-by-step logic pathways for how model outputs are derived."
    ]
  },
  {
    id: "p4",
    title: "Human Oversight & Accountability",
    icon: UserCheck,
    color: "bg-green-50 text-green-600 border-green-100",
    description: "People must remain in ultimate control of our technology. We enforce 'human-in-the-loop' systems for high-risk AI, ensuring clear escalation pipelines and human accountability for critical decisions.",
    gdprLinks: ["Article 22 - Automated Decisions & Profiling", "EU AI Act Article 14 - Human Oversight"],
    practicalTips: [
      "Always implement a seamless, one-click fallback to a live human operator in conversational bots.",
      "Train human reviewers to critically evaluate AI recommendations, preventing automation bias.",
      "Maintain a clear register of operational owners and technical leads accountable for model behavior."
    ]
  },
  {
    id: "p5",
    title: "Safety, Security & Reliability",
    icon: Activity,
    color: "bg-purple-50 text-purple-600 border-purple-100",
    description: "AI systems must be robust and secure against malicious attacks, prompt injections, and data poisons. Models must perform reliably under unexpected conditions without generating toxic outputs.",
    gdprLinks: ["Article 32 - Security of Processing", "EU AI Act Article 15 - Accuracy, Robustness and Cybersecurity"],
    practicalTips: [
      "Employ robust system instruction prompt guardrails to block jailbreaking and prompt leak.",
      "Conduct adversarial red-teaming tests on model boundaries before production release.",
      "Use only Vodafone-approved secure GenAI gateways with enterprise-grade data protection."
    ]
  }
];

export default function PrinciplesGuide() {
  return (
    <div id="principles-guide-container" className="space-y-8">
      {/* Header section with Vodafone Red branding */}
      <div id="guide-header" className="border-b border-gray-100 pb-6">
        <h1 id="guide-title" className="text-3xl font-bold tracking-tight text-gray-900">
          Vodafone AI Ethical & Privacy Commitments
        </h1>
        <p id="guide-desc" className="mt-2 text-sm text-gray-500 max-w-3xl">
          At Vodafone, we believe that artificial intelligence must respect human rights, data protection, and transparency. 
          Use this guide to align your project design with our 5 core principles, ensuring rapid, compliant sign-off by the Vodafone Privacy Team.
        </p>
      </div>

      {/* Grid of 5 principles */}
      <div id="principles-grid" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {principles.map((principle, index) => {
          const Icon = principle.icon;
          return (
            <motion.div
              id={`principle-card-${principle.id}`}
              key={principle.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className="bg-white border border-gray-100 rounded-xl p-6 shadow-xs hover:shadow-md transition-shadow duration-200 flex flex-col justify-between"
            >
              <div id={`principle-header-${principle.id}`}>
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-lg border ${principle.color}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">{principle.title}</h3>
                </div>
                <p className="mt-3 text-sm text-gray-600 leading-relaxed">{principle.description}</p>
                
                {/* Practical Developer Tips */}
                <div className="mt-5 space-y-2.5">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-400">Compliance Code of Conduct</h4>
                  <ul className="space-y-1.5">
                    {principle.practicalTips.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-gray-600">
                        <CheckCircle2 className="h-3.5 w-3.5 text-red-500 mt-0.5 shrink-0" />
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Regulatory Mapping */}
              <div id={`principle-footer-${principle.id}`} className="mt-6 pt-4 border-t border-gray-50 flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-medium text-gray-400 uppercase tracking-wider">Regulatory Mapping:</span>
                {principle.gdprLinks.map((link, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center rounded-md bg-gray-50 px-2 py-1 text-[10px] font-medium text-gray-600 ring-1 ring-inset ring-gray-500/10"
                  >
                    {link}
                  </span>
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* EU AI Act Quick Summary banner */}
      <div id="ai-act-banner" className="bg-red-50/50 border border-red-100 rounded-xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div id="banner-text">
          <h3 className="text-base font-semibold text-gray-900">Understanding the EU AI Act</h3>
          <p className="mt-1 text-xs text-gray-600 max-w-2xl leading-relaxed">
            The EU AI Act classifies AI systems based on their potential risk to safety and human rights. 
            <strong> Prohibited systems</strong> (e.g. social scoring) are banned. 
            <strong> High-Risk systems</strong> (e.g. HR, critical infrastructure) require comprehensive audits, logging, and registration. 
            Our automated Gemini reviewer will help classify your project under these categories.
          </p>
        </div>
        <a
          href="https://artificialintelligenceact.eu"
          target="_blank"
          referrerPolicy="no-referrer"
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg shrink-0 cursor-pointer transition-colors"
        >
          <span>Official AI Act Portal</span>
          <ArrowRight className="h-3.5 w-3.5" />
        </a>
      </div>
    </div>
  );
}
