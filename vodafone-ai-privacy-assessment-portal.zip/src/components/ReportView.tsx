/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  ArrowLeft, FileText, Printer, CheckCircle, AlertTriangle, AlertOctagon, 
  Info, ShieldCheck, Mail, User, Building, Clock, Check, X, Plus, Trash2, HelpCircle 
} from "lucide-react";
import { AIProject, ProjectStatus } from "../types";
import { motion } from "motion/react";

interface ReportViewProps {
  project: AIProject;
  onBack: () => void;
  onUpdateStatus: (projectId: string, status: ProjectStatus, notes: string, conditions: string[], signer: string) => void;
}

export default function ReportView({ project, onBack, onUpdateStatus }: ReportViewProps) {
  const [reviewerNotes, setReviewerNotes] = useState(project.reviewerNotes || "");
  const [conditions, setConditions] = useState<string[]>(project.conditions || []);
  const [newCondition, setNewCondition] = useState("");
  const [status, setStatus] = useState<ProjectStatus>(project.status);
  const [signer, setSigner] = useState(project.signOffBy || "Vodafone Privacy Officer");
  const [isSaved, setIsSaved] = useState(false);

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "Critical":
        return <span className="inline-flex items-center gap-1 bg-purple-100 text-purple-800 text-xs font-bold px-3 py-1 rounded-full border border-purple-200"><AlertOctagon className="h-3.5 w-3.5" /> Critical Risk</span>;
      case "High":
        return <span className="inline-flex items-center gap-1 bg-red-100 text-red-800 text-xs font-bold px-3 py-1 rounded-full border border-red-200"><AlertTriangle className="h-3.5 w-3.5" /> High Risk</span>;
      case "Medium":
        return <span className="inline-flex items-center gap-1 bg-orange-100 text-orange-800 text-xs font-bold px-3 py-1 rounded-full border border-orange-200"><AlertTriangle className="h-3.5 w-3.5" /> Medium Risk</span>;
      case "Low":
        return <span className="inline-flex items-center gap-1 bg-green-100 text-green-800 text-xs font-bold px-3 py-1 rounded-full border border-green-200"><CheckCircle className="h-3.5 w-3.5" /> Low Risk</span>;
      default:
        return <span className="inline-flex items-center gap-1 bg-gray-100 text-gray-800 text-xs font-bold px-3 py-1 rounded-full">Unassessed</span>;
    }
  };

  const getStatusBadge = (s: ProjectStatus) => {
    switch (s) {
      case "Approved":
        return <span className="bg-green-100 text-green-800 text-xs font-semibold px-2.5 py-0.5 rounded-md border border-green-200">Approved</span>;
      case "Approved with Conditions":
        return <span className="bg-yellow-100 text-yellow-800 text-xs font-semibold px-2.5 py-0.5 rounded-md border border-yellow-200">Approved with Conditions</span>;
      case "In Review":
        return <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded-md border border-blue-200">In Review</span>;
      case "Rejected":
        return <span className="bg-red-100 text-red-800 text-xs font-semibold px-2.5 py-0.5 rounded-md border border-red-200">Rejected</span>;
      default:
        return <span className="bg-gray-100 text-gray-800 text-xs font-semibold px-2.5 py-0.5 rounded-md border border-gray-200">{s}</span>;
    }
  };

  const getAIActBadge = (c: string) => {
    switch (c) {
      case "Prohibited":
        return <span className="bg-red-900 text-white text-[11px] font-bold px-2.5 py-1 rounded-md border border-red-950">Prohibited AI</span>;
      case "High-Risk":
        return <span className="bg-red-100 text-red-800 text-[11px] font-bold px-2.5 py-1 rounded-md border border-red-200">High-Risk (Annex III)</span>;
      case "Limited Risk":
        return <span className="bg-blue-100 text-blue-800 text-[11px] font-bold px-2.5 py-1 rounded-md border border-blue-200">Limited Risk</span>;
      default:
        return <span className="bg-green-100 text-green-800 text-[11px] font-bold px-2.5 py-1 rounded-md border border-green-200">Minimal Risk</span>;
    }
  };

  const handleAddCondition = () => {
    if (newCondition.trim()) {
      setConditions([...conditions, newCondition.trim()]);
      setNewCondition("");
    }
  };

  const handleRemoveCondition = (idx: number) => {
    setConditions(conditions.filter((_, i) => i !== idx));
  };

  const handlePrint = () => {
    window.print();
  };

  const handleSaveReview = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateStatus(project.id, status, reviewerNotes, conditions, signer);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const scoreColor = (score: number) => {
    if (score >= 90) return "text-green-600 border-green-200 bg-green-50";
    if (score >= 70) return "text-orange-600 border-orange-200 bg-orange-50";
    return "text-red-600 border-red-200 bg-red-50";
  };

  return (
    <div id="report-view-container" className="space-y-6">
      {/* Printable page controls */}
      <div id="report-controls" className="flex flex-wrap items-center justify-between gap-4 print:hidden">
        <button
          id="btn-report-back"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-gray-600 hover:text-gray-900 cursor-pointer transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Projects Dashboard</span>
        </button>

        <button
          id="btn-report-print"
          onClick={handlePrint}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-gray-900 hover:bg-gray-800 text-xs font-bold text-white rounded-lg cursor-pointer shadow-sm hover:shadow-md transition-colors"
        >
          <Printer className="h-4 w-4" />
          <span>Print / Export Compliance Report</span>
        </button>
      </div>

      {/* Main Dossier Card */}
      <div id="printable-dossier" className="bg-white border border-gray-100 rounded-2xl shadow-xs p-8 space-y-8 print:border-none print:shadow-none print:p-0">
        {/* Vodafone Branding Header */}
        <div id="dossier-header" className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-gray-100 pb-6 gap-6">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-red-600 flex items-center justify-center text-white font-black text-2xl tracking-tighter">
              v
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-bold text-red-600 tracking-widest uppercase">Vodafone Group Privacy</span>
                <span className="h-3 w-px bg-gray-200" />
                <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest">AI Compliance Assessment</span>
              </div>
              <h1 className="text-xl font-bold tracking-tight text-gray-900 mt-1">{project.name}</h1>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1.5 text-right shrink-0">
            <span className="text-[10px] font-semibold text-gray-400 uppercase">Assessment ID: {project.id}</span>
            <div className="flex gap-2">
              {getRiskBadge(project.riskRating)}
              {getStatusBadge(project.status)}
            </div>
          </div>
        </div>

        {/* Info Grid */}
        <div id="dossier-info-grid" className="grid grid-cols-2 md:grid-cols-4 gap-6 bg-gray-50 rounded-xl p-5 border border-gray-100 print:bg-white print:border-gray-200">
          <div className="space-y-0.5">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1"><Building className="h-3 w-3" /> Department</span>
            <p className="text-xs font-semibold text-gray-800">{project.department}</p>
          </div>
          <div className="space-y-0.5">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1"><User className="h-3 w-3" /> Project Lead</span>
            <p className="text-xs font-semibold text-gray-800">{project.leadName}</p>
          </div>
          <div className="space-y-0.5">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1"><Mail className="h-3 w-3" /> Contact</span>
            <p className="text-xs font-semibold text-gray-800 truncate">{project.leadEmail}</p>
          </div>
          <div className="space-y-0.5">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1"><Clock className="h-3 w-3" /> Submitted</span>
            <p className="text-xs font-semibold text-gray-800">
              {new Date(project.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
            </p>
          </div>
        </div>

        {/* Project Description */}
        <div id="dossier-description" className="space-y-2">
          <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="h-4 w-4 text-gray-400" /> Project Intent & Design Description
          </h2>
          <p className="text-xs text-gray-600 leading-relaxed bg-white border border-gray-100 p-4 rounded-xl">
            {project.description}
          </p>
        </div>

        {/* Gemini Privacy AI Analysis Report */}
        {project.aiAnalysis ? (
          <div id="gemini-ai-analysis-block" className="space-y-6">
            <div className="flex items-center gap-2 border-b border-gray-100 pb-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-red-100 text-red-600">
                ★
              </span>
              <h2 className="text-base font-bold text-gray-900">Gemini Automated Privacy & Regulatory Evaluation</h2>
            </div>

            {/* Scorecard block */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="border border-gray-100 rounded-xl p-5 bg-white flex flex-col justify-between h-36">
                <div>
                  <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Compliance Score</h4>
                  <p className="text-[10px] text-gray-500 mt-0.5">General GDPR compliance rating based on current safeguards.</p>
                </div>
                <div className="flex items-baseline gap-2 mt-4">
                  <span className={`inline-flex items-center justify-center h-12 w-12 rounded-full border text-lg font-black ${scoreColor(project.aiAnalysis.complianceScore)}`}>
                    {project.aiAnalysis.complianceScore}%
                  </span>
                  <span className="text-[11px] text-gray-400">Readiness Rating</span>
                </div>
              </div>

              <div className="border border-gray-100 rounded-xl p-5 bg-white flex flex-col justify-between h-36">
                <div>
                  <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">EU AI Act Classification</h4>
                  <p className="text-[10px] text-gray-500 mt-0.5">Risk tier matching the formal European Artificial Intelligence regulations.</p>
                </div>
                <div className="mt-4">
                  {getAIActBadge(project.aiAnalysis.euAiActClassification)}
                </div>
              </div>

              <div className="border border-gray-100 rounded-xl p-5 bg-white flex flex-col justify-between h-36">
                <div>
                  <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">DPIA Requirement</h4>
                  <p className="text-[10px] text-gray-500 mt-0.5">Determines if a formal GDPR Article 35 impact assessment is mandatory.</p>
                </div>
                <div className="flex items-center gap-2 mt-4">
                  {project.aiAnalysis.dpiaRequired ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-100 text-red-800 text-[11px] font-bold rounded-md border border-red-200">DPIA MANDATORY</span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-100 text-green-800 text-[11px] font-bold rounded-md border border-green-200">DPIA NOT REQUIRED</span>
                  )}
                </div>
              </div>
            </div>

            {/* Sub-details: Risks vs Recommendations */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
              {/* Key Risks */}
              <div className="bg-red-50/30 border border-red-100 rounded-xl p-5 space-y-4">
                <h3 className="text-xs font-bold text-red-900 uppercase tracking-wider flex items-center gap-1.5"><AlertTriangle className="h-4 w-4 text-red-600" /> Privacy & Regulatory Risks Identified</h3>
                <ul className="space-y-3">
                  {project.aiAnalysis.keyRisks.map((risk, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-gray-700 leading-relaxed">
                      <div className="h-1.5 w-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                      <span>{risk}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Actionable Recommendations */}
              <div className="bg-green-50/30 border border-green-100 rounded-xl p-5 space-y-4">
                <h3 className="text-xs font-bold text-green-900 uppercase tracking-wider flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-green-600" /> Mandatory Mitigation Actions</h3>
                <ul className="space-y-3">
                  {project.aiAnalysis.recommendations.map((rec, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-gray-700 leading-relaxed">
                      <div className="h-4 w-4 bg-green-100 text-green-800 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                        {idx + 1}
                      </div>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Legal Basis & DPIA Justification */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-gray-100 rounded-xl p-5 space-y-2 bg-white">
                <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">GDPR Article 6 Legal Processing Basis</h4>
                <p className="text-xs font-semibold text-gray-800">{project.aiAnalysis.legalBasis}</p>
                <p className="text-[11px] text-gray-500 leading-relaxed">
                  Vodafone services must operate under strict, pre-approved legal processing grounds. 
                  This AI design should align with the specified base in customer terms of service or privacy disclosures.
                </p>
              </div>

              <div className="border border-gray-100 rounded-xl p-5 space-y-2 bg-white">
                <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">DPIA Justification Details</h4>
                <p className="text-xs text-gray-700 leading-relaxed">{project.aiAnalysis.dpiaJustification}</p>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 text-xs text-gray-600 leading-relaxed print:hidden">
              <span className="font-bold text-gray-700">AI Risk Justification: </span>
              {project.aiAnalysis.riskJustification}
            </div>
          </div>
        ) : (
          <div className="border border-gray-100 rounded-xl p-8 text-center text-xs text-gray-500">
            No AI compliance review logs generated. This draft was created without AI assist.
          </div>
        )}

        {/* Questionnaire Response Details */}
        <div id="questionnaire-details-block" className="space-y-4 pt-4 border-t border-gray-100">
          <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck className="h-4.5 w-4.5 text-gray-400" /> Completed Technical Privacy Questionnaire
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Sec 1 */}
            <div className="border border-gray-100 rounded-xl p-4 space-y-3 bg-white">
              <h4 className="font-bold text-gray-900 border-b border-gray-50 pb-1">Data Minimization & Ingestion</h4>
              <div className="space-y-2">
                <div className="flex justify-between gap-2 border-b border-gray-50 pb-1.5">
                  <span className="text-gray-500">Data Types:</span>
                  <span className="font-medium text-gray-800 text-right">{project.answers.dataTypes.join(", ")}</span>
                </div>
                <div className="flex justify-between gap-2 border-b border-gray-50 pb-1.5">
                  <span className="text-gray-500">Minimization Active?</span>
                  <span className={`font-semibold ${project.answers.dataMinimized ? "text-green-600" : "text-red-500"}`}>
                    {project.answers.dataMinimized ? "Yes" : "No"}
                  </span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-gray-500">Retention:</span>
                  <span className="font-medium text-gray-800">{project.answers.dataRetentionPeriod}</span>
                </div>
                {project.answers.dataMinimized && (
                  <div className="bg-gray-50 p-2.5 rounded-lg text-[11px] text-gray-600 mt-1 leading-relaxed">
                    <span className="font-semibold text-gray-700">Minimization Protocol: </span>
                    {project.answers.dataMinimizationExplanation}
                  </div>
                )}
              </div>
            </div>

            {/* Sec 2 */}
            <div className="border border-gray-100 rounded-xl p-4 space-y-3 bg-white">
              <h4 className="font-bold text-gray-900 border-b border-gray-50 pb-1">Model Training & Fairness</h4>
              <div className="space-y-2">
                <div className="flex justify-between gap-2 border-b border-gray-50 pb-1.5">
                  <span className="text-gray-500">Training Source:</span>
                  <span className="font-medium text-gray-800 text-right">{project.answers.trainingDataSource}</span>
                </div>
                <div className="flex justify-between gap-2 border-b border-gray-50 pb-1.5">
                  <span className="text-gray-500">Bias Evaluated?</span>
                  <span className={`font-semibold ${project.answers.biasChecked ? "text-green-600" : "text-gray-500"}`}>
                    {project.answers.biasChecked ? "Yes" : "No"}
                  </span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-gray-500">Synthetic Data:</span>
                  <span className="font-medium text-gray-800">{project.answers.syntheticDataUsed ? "Yes" : "No"}</span>
                </div>
                {project.answers.biasChecked && (
                  <div className="bg-gray-50 p-2.5 rounded-lg text-[11px] text-gray-600 mt-1 leading-relaxed">
                    <span className="font-semibold text-gray-700">Fairness Controls: </span>
                    {project.answers.biasMitigationExplanation}
                  </div>
                )}
              </div>
            </div>

            {/* Sec 3 */}
            <div className="border border-gray-100 rounded-xl p-4 space-y-3 bg-white">
              <h4 className="font-bold text-gray-900 border-b border-gray-50 pb-1">Automated Decisions & Oversight</h4>
              <div className="space-y-2">
                <div className="flex justify-between gap-2 border-b border-gray-50 pb-1.5">
                  <span className="text-gray-500">Profiling or Decisions?</span>
                  <span className={`font-semibold ${project.answers.automatedDecisionMaking ? "text-orange-600" : "text-gray-500"}`}>
                    {project.answers.automatedDecisionMaking ? "Yes (GDPR Art. 22)" : "No"}
                  </span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-gray-500">Oversight Mechanism:</span>
                  <span className="font-medium text-gray-800 text-right">{project.answers.humanOversightMechanism || "Not Specified"}</span>
                </div>
                {project.answers.automatedDecisionMaking && (
                  <div className="bg-gray-50 p-2.5 rounded-lg text-[11px] text-gray-600 mt-1 leading-relaxed">
                    <span className="font-semibold text-gray-700">Decision Logic: </span>
                    {project.answers.automatedDecisionExplanation}
                  </div>
                )}
              </div>
            </div>

            {/* Sec 4 */}
            <div className="border border-gray-100 rounded-xl p-4 space-y-3 bg-white">
              <h4 className="font-bold text-gray-900 border-b border-gray-50 pb-1">Vendors & Cross-Border Logistics</h4>
              <div className="space-y-2">
                <div className="flex justify-between gap-2 border-b border-gray-50 pb-1.5">
                  <span className="text-gray-500">Third-Party Vendor?</span>
                  <span className="font-medium text-gray-800">{project.answers.thirdPartyVendor ? "Yes" : "No"}</span>
                </div>
                <div className="flex justify-between gap-2 border-b border-gray-50 pb-1.5">
                  <span className="text-gray-500">Data Location:</span>
                  <span className="font-semibold text-gray-800">{project.answers.dataLocation}</span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-gray-500">Cross-Border Transfer:</span>
                  <span className={`font-semibold ${project.answers.crossBorderTransfer ? "text-red-500" : "text-green-600"}`}>
                    {project.answers.crossBorderTransfer ? "Yes" : "No"}
                  </span>
                </div>
                {project.answers.thirdPartyVendor && (
                  <div className="bg-gray-50 p-2 py-1.5 rounded-lg text-[10px] text-gray-600 mt-0.5">
                    <span className="font-semibold text-gray-700">Vendor details: </span>{project.answers.thirdPartyDetails}
                  </div>
                )}
                {project.answers.crossBorderTransfer && (
                  <div className="bg-gray-50 p-2 py-1.5 rounded-lg text-[10px] text-gray-600 mt-0.5">
                    <span className="font-semibold text-gray-700">Safeguards: </span>{project.answers.crossBorderDetails}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Existing REVIEW SECTION (Only visible if approved/resolved) */}
        {(project.reviewerNotes || project.conditions.length > 0) && (
          <div id="historic-reviews-block" className="space-y-4 pt-6 border-t border-gray-100">
            <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-1.5">
              <CheckCircle className="h-4.5 w-4.5 text-red-600" /> Active Vodafone Privacy Sign-Off Details
            </h2>
            <div className="bg-red-50/20 border border-red-100 rounded-xl p-5 space-y-4 text-xs">
              {project.reviewerNotes && (
                <div className="space-y-1">
                  <h4 className="font-bold text-gray-800">Privacy Officer Assessment Notes:</h4>
                  <p className="text-gray-600 leading-relaxed">{project.reviewerNotes}</p>
                </div>
              )}
              {project.conditions.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-bold text-gray-800">Assurance Conditions For Safe Rollout:</h4>
                  <ul className="space-y-1.5">
                    {project.conditions.map((cond, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-gray-600">
                        <Check className="h-3.5 w-3.5 text-red-600 shrink-0 mt-0.5" />
                        <span>{cond}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {(project.signOffBy || project.signOffDate) && (
                <div className="pt-3 border-t border-red-100/50 flex flex-wrap justify-between text-[11px] text-gray-500">
                  <span>Authorized Signee: <strong className="text-gray-700">{project.signOffBy}</strong></span>
                  <span>E-Signature Date: <strong className="text-gray-700">{project.signOffDate}</strong></span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* PRIVACY OFFICER REVIEW DECISION WORKBENCH */}
      <div id="privacy-officer-decision-workbench" className="bg-gray-900 text-gray-100 rounded-2xl p-8 space-y-6 print:hidden">
        <div className="flex items-center gap-3 border-b border-gray-800 pb-4">
          <ShieldCheck className="h-6 w-6 text-red-500" />
          <div>
            <h3 className="text-lg font-bold">Vodafone Privacy Team Review Console</h3>
            <p className="text-xs text-gray-400">Perform legal audit, attach deployment conditions, and update sign-off status.</p>
          </div>
        </div>

        <form id="signoff-form" onSubmit={handleSaveReview} className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="signoff-status" className="text-xs font-semibold text-gray-300">Compliance Decision *</label>
              <select
                id="signoff-status"
                value={status}
                onChange={e => setStatus(e.target.value as ProjectStatus)}
                className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-800 bg-gray-950 text-gray-100 focus:outline-hidden focus:border-red-500"
              >
                <option value="In Review">Keep In Review</option>
                <option value="Approved">Approve Deployment</option>
                <option value="Approved with Conditions">Approve with Custom Conditions</option>
                <option value="Rejected">Reject Project Ingestion</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="signoff-signer" className="text-xs font-semibold text-gray-300">Authorized Privacy Officer E-Signature *</label>
              <input
                id="signoff-signer"
                type="text"
                required
                placeholder="Name of Signee"
                value={signer}
                onChange={e => setSigner(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-800 bg-gray-950 text-gray-100 focus:outline-hidden focus:border-red-500"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="signoff-notes" className="text-xs font-semibold text-gray-300">Legal Audit & Privacy Officer Review Notes</label>
            <textarea
              id="signoff-notes"
              rows={3}
              placeholder="Provide professional notes on GDPR compliance, vendor assessments, or DPIA details to guide the engineering team..."
              value={reviewerNotes}
              onChange={e => setReviewerNotes(e.target.value)}
              className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-gray-800 bg-gray-950 text-gray-100 focus:outline-hidden focus:border-red-500 leading-relaxed"
            />
          </div>

          {/* Condition addition block */}
          {status === "Approved with Conditions" && (
            <div className="space-y-3 bg-gray-950/50 border border-gray-800 p-4 rounded-xl">
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-gray-300">Configure Rollout Conditions</h4>
                <p className="text-[10px] text-gray-400">Specify precise, legal conditions the engineering team must meet prior to production launching.</p>
              </div>

              <div className="flex gap-2">
                <input
                  id="input-new-condition"
                  type="text"
                  placeholder="e.g. Prompt validation logs must be audited monthly..."
                  value={newCondition}
                  onChange={e => setNewCondition(e.target.value)}
                  className="flex-1 text-xs px-3 py-2 rounded-lg border border-gray-800 bg-gray-950 text-gray-100 focus:outline-hidden"
                />
                <button
                  id="btn-add-condition"
                  type="button"
                  onClick={handleAddCondition}
                  className="px-3.5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-xs font-bold text-white shrink-0 cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              {conditions.length > 0 && (
                <ul className="space-y-1.5 pt-2 border-t border-gray-800/40">
                  {conditions.map((cond, idx) => (
                    <li key={idx} className="flex items-center justify-between gap-3 bg-gray-900 border border-gray-800 p-2 rounded-lg text-xs text-gray-300">
                      <span>{cond}</span>
                      <button
                        id={`btn-remove-cond-${idx}`}
                        type="button"
                        onClick={() => handleRemoveCondition(idx)}
                        className="text-gray-400 hover:text-red-500 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          <div className="flex items-center justify-between pt-4 border-t border-gray-800">
            <span className="text-[10px] text-gray-400">Ensuring regulatory compliance across Vodafone's AI ecosystem.</span>
            <button
              id="btn-signoff-submit"
              type="submit"
              className="inline-flex items-center gap-1.5 px-6 py-2.5 bg-red-600 hover:bg-red-700 text-xs font-bold text-white rounded-lg cursor-pointer shadow-sm hover:shadow-md transition-colors"
            >
              <Check className="h-4 w-4" />
              <span>Publish Sign-Off Ledger</span>
            </button>
          </div>

          {isSaved && (
            <motion.div
              id="save-success-indicator"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xs text-center font-semibold text-green-400"
            >
              ✔ Sign-off ledger successfully updated and published!
            </motion.div>
          )}
        </form>
      </div>
    </div>
  );
}
