/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AIProject } from "./types";

export const mockProjects: AIProject[] = [
  {
    id: "proj-tobi-genai",
    name: "TOBI Digital Assistant GenAI Upgrade",
    description: "Upgrading the core Vodafone customer support chatbot (TOBI) with LLM capabilities to handle complex customer queries, retrieve account billing data from backend APIs, and provide personalized tariff advice.",
    department: "Customer Operations",
    leadName: "Sarah Jenkins",
    leadEmail: "sarah.jenkins@vodafone.com",
    status: "In Review",
    createdAt: "2026-07-10T10:00:00Z",
    updatedAt: "2026-07-18T14:30:00Z",
    riskRating: "High",
    reviewerNotes: "Requires review of conversational safety. Customer PII is retrieved dynamically from the CRM. LLM prompt injection guards are critical. GDPR Article 6 legal basis should be Contractual Necessity or Legitimate Interests.",
    conditions: [
      "Deploy robust prompt safety guardrails to detect and block malicious customer inputs.",
      "Mask sensitive data (credit cards, passwords) at the ingestion layer before passing payloads to the LLM.",
      "Offer customers an immediate, easily accessible option to transfer to a human agent at any point."
    ],
    signOffBy: "",
    signOffDate: "",
    answers: {
      dataTypes: ["Customer PII", "Traffic/Call Logs", "Financial"],
      dataMinimized: true,
      dataMinimizationExplanation: "Only customer name, account number, and recent billing/usage details required for query resolution are loaded into the chat context. Memory is purged 30 minutes after session termination.",
      dataRetentionPeriod: "Chat history logs are retained for 90 days for quality assurance, then automatically purged.",
      trainingDataSource: "Licensed third-party foundation model combined with internal sanitized support transcripts.",
      syntheticDataUsed: false,
      biasChecked: true,
      biasMitigationExplanation: "The prompt and system instructions are tested with a diverse suite of 500+ customer scenarios to check for unfair treatment, stereotyping, or language bias.",
      automatedDecisionMaking: false,
      automatedDecisionExplanation: "The assistant does not make legally binding decisions or tariff changes without explicit customer confirmation.",
      humanOversightMechanism: "Live monitoring queue for supervisors, and immediate 'transfer to human' button for users.",
      thirdPartyVendor: true,
      thirdPartyDetails: "Using Microsoft Azure OpenAI deployment under Vodafone European Enterprise Agreement (ensures no data is used for model training).",
      dataLocation: "EU",
      crossBorderTransfer: false,
      crossBorderDetails: "All data processing resides within European Azure regions (Dublin and Amsterdam).",
      generativeAI: true,
      genAIPromptSafety: true,
      userOptOutAvailable: true
    },
    aiAnalysis: {
      overallRisk: "High",
      riskJustification: "Processing of Customer PII, billing history (financial details), and chatbot conversations with generative AI technology qualifies this as High Risk. There is a potential risk of LLM hallucinations regarding tariffs or customer agreements, and high risk of prompt leak if not secured.",
      complianceScore: 78,
      keyRisks: [
        "Unrestricted LLM access to billing databases without secondary token checks.",
        "Potential leak of conversational PII into external cloud systems if endpoints misconfigured.",
        "Regulatory compliance under GDPR Article 22 if the chatbot automatically switches tariff plans without explicit human action."
      ],
      recommendations: [
        "Enforce rigorous input-output sanitation on chatbot interfaces.",
        "Add strict token-based authorization for all backend database queries made by TOBI.",
        "Ensure the customer's legal right to clear information (GDPR Art. 13/14) is respected by explicitly showing a 'Generative AI Assistant' disclaimer."
      ],
      dpiaRequired: true,
      dpiaJustification: "Processing personal customer communications, billing context, and generative conversational AI on a large scale triggers Article 35 GDPR DPIA requirements.",
      legalBasis: "Contractual Necessity (Article 6(1)(b)) for executing customer queries, and Consent for chat logging.",
      euAiActClassification: "Limited Risk"
    }
  },
  {
    id: "proj-net-predict",
    name: "Network Traffic Congestion Predictor",
    description: "An AI system analyzing aggregate network cell tower load, signal strength, and generic connection logs to dynamically allocate network bandwidth and predict congestion in high-density urban areas.",
    department: "Network & Technology",
    leadName: "Marcus Thorne",
    leadEmail: "marcus.thorne@vodafone.com",
    status: "Approved",
    createdAt: "2026-06-15T09:15:00Z",
    updatedAt: "2026-06-20T11:00:00Z",
    riskRating: "Low",
    reviewerNotes: "Excellent example of privacy-by-design. All metrics are fully anonymized. No customer identities, subscriber MSISDNs, or locations are tracked. Purely infrastructure metadata.",
    conditions: [
      "Maintain strict aggregation at the cell tower level; do not correlate metrics back to specific IMEI or IMSI codes."
    ],
    signOffBy: "David Miller (Privacy Officer)",
    signOffDate: "2026-06-20",
    answers: {
      dataTypes: ["Public/Non-personal"],
      dataMinimized: true,
      dataMinimizationExplanation: "No customer personal data is ingested. The system uses aggregate load factors, drop call rates, and signal DB measurements stripped of individual identifiers.",
      dataRetentionPeriod: "Aggregate statistics are archived for 12 months for seasonal analysis.",
      trainingDataSource: "Internal Vodafone technical network telemetry.",
      syntheticDataUsed: true,
      biasChecked: false,
      biasMitigationExplanation: "Not applicable as metrics do not involve human demographics or behaviors.",
      automatedDecisionMaking: true,
      automatedDecisionExplanation: "Automatically optimizes cell tower power distribution and radio frequency tilt to manage load. No human/customer decisions.",
      humanOversightMechanism: "Network engineers receive alarms and can override automated power shifts via the cell control panel.",
      thirdPartyVendor: false,
      thirdPartyDetails: "",
      dataLocation: "UK",
      crossBorderTransfer: false,
      crossBorderDetails: "",
      generativeAI: false,
      genAIPromptSafety: false,
      userOptOutAvailable: false
    },
    aiAnalysis: {
      overallRisk: "Low",
      riskJustification: "The project strictly processes non-personal telemetry data. No PII is collected, tracked, or inferred, resulting in negligible risk to individual privacy.",
      complianceScore: 100,
      keyRisks: [
        "Risk of de-anonymization if cellular tower density becomes extremely low (e.g. single subscriber area), though practically highly unlikely."
      ],
      recommendations: [
        "Ensure regular audits verify that no unique network identifiers (IMSI, IMEI, IP addresses) are added to the prediction inputs."
      ],
      dpiaRequired: false,
      dpiaJustification: "No personal data is processed, therefore a Data Protection Impact Assessment is not legally required.",
      legalBasis: "Not applicable (Processing of non-personal data)",
      euAiActClassification: "Minimal Risk"
    }
  },
  {
    id: "proj-hr-resume",
    name: "Vodafone Talent Matching AI",
    description: "An automated system that screens and scores job applicant resumes against open Vodafone engineering and business job postings to recommend the top 10% of candidates for recruiter interviews.",
    department: "Human Resources",
    leadName: "Elena Rostova",
    leadEmail: "elena.rostova@vodafone.com",
    status: "Approved with Conditions",
    createdAt: "2026-05-01T08:30:00Z",
    updatedAt: "2026-05-12T16:45:00Z",
    riskRating: "Critical",
    reviewerNotes: "High risk under the EU AI Act (employment and recruiting AI). Subject to stringent compliance regulations. Clear human oversight and fairness logs are mandatory.",
    conditions: [
      "The system must only recommend candidates; it must not automatically reject or advance candidates without human recruiter validation.",
      "Conduct quarterly algorithmic bias reviews across gender, age, and ethnicity parameters.",
      "Keep resumes and scoring outputs strictly within UK HR systems."
    ],
    signOffBy: "Elena Rostova (Lead) & Claire Duval (Group Privacy)",
    signOffDate: "2026-05-12",
    answers: {
      dataTypes: ["Employee Data"],
      dataMinimized: true,
      dataMinimizationExplanation: "Ingests candidate name, work history, skills, and education. Sensitive fields like age, gender, address, and profile pictures are completely masked during the screening phase.",
      dataRetentionPeriod: "Candidate data is retained for 6 months after application conclusion, aligned with global HR retention rules.",
      trainingDataSource: "Historical successful resumes and standard corporate occupational templates.",
      syntheticDataUsed: false,
      biasChecked: true,
      biasMitigationExplanation: "Masking demographic variables. Standardized testing using mock resumes with intentionally varied names/genders to verify identical score outcomes.",
      automatedDecisionMaking: true,
      automatedDecisionExplanation: "Scores resumes on a scale of 1-100 to sort applicants. Recruiter makes final selection.",
      humanOversightMechanism: "Every recommended top candidate is manually reviewed by HR before an interview offer is extended. Recruiter can view and reverse any AI-generated score.",
      thirdPartyVendor: true,
      thirdPartyDetails: "Workday AI recruiting add-on.",
      dataLocation: "EU",
      crossBorderTransfer: true,
      crossBorderDetails: "Workday processors situated in Germany and Ireland.",
      generativeAI: false,
      genAIPromptSafety: false,
      userOptOutAvailable: true
    },
    aiAnalysis: {
      overallRisk: "Critical",
      riskJustification: "AI systems utilized for HR screening and recruitment are explicitly classified as High-Risk under Annex III of the EU AI Act due to the profound impact on individuals' employment opportunities. It carries substantial compliance responsibilities, including bias prevention, logging, and human-in-the-loop oversight.",
      complianceScore: 82,
      keyRisks: [
        "Inherent historical training dataset bias which may favor traditional demographic hiring patterns.",
        "Failure to satisfy Article 22 GDPR if candidate profiling is used to automatically reject applicants without manual evaluation.",
        "Exposures of resume PII to third-party vendor platforms."
      ],
      recommendations: [
        "Perform a mandatory EU AI Act conformity assessment.",
        "Publish a transparent candidate privacy notice explaining the use, criteria, and weights of the screening algorithm.",
        "Provide candidates with a clear, direct channel to request manual human resume review of their profile."
      ],
      dpiaRequired: true,
      dpiaJustification: "Systematic evaluation of personal aspects of natural persons, including profiling and recruitment matching on a large scale, makes a DPIA mandatory under Article 35(3)(a) GDPR.",
      legalBasis: "Consent (Article 6(1)(a)) during the candidate application registration process.",
      euAiActClassification: "High-Risk"
    }
  }
];
