/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ProjectStatus = 'Draft' | 'Submitted' | 'In Review' | 'Approved' | 'Approved with Conditions' | 'Rejected';
export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical' | 'Unassessed';

export interface AssessmentAnswers {
  // Section 1: Data Collection & Minimization
  dataTypes: string[]; // Customer PII, Employee Data, Location Data, Traffic/Call Logs, Biometric, Financial, Public/Non-personal
  dataMinimized: boolean;
  dataMinimizationExplanation: string;
  dataRetentionPeriod: string;

  // Section 2: Training Data & Bias
  trainingDataSource: string; // Internal proprietary, Public internet scrape, Licensed third-party, Synthetic
  syntheticDataUsed: boolean;
  biasChecked: boolean;
  biasMitigationExplanation: string;

  // Section 3: Automation & Oversight
  automatedDecisionMaking: boolean;
  automatedDecisionExplanation: string;
  humanOversightMechanism: string;

  // Section 4: Security, Sharing & Location
  thirdPartyVendor: boolean;
  thirdPartyDetails: string;
  dataLocation: string; // EU, UK, US, Global, Other
  crossBorderTransfer: boolean;
  crossBorderDetails: string;

  // Section 5: Generative AI specific
  generativeAI: boolean;
  genAIPromptSafety: boolean;
  userOptOutAvailable: boolean;
}

export interface AIAnalysis {
  overallRisk: 'Low' | 'Medium' | 'High' | 'Critical';
  riskJustification: string;
  complianceScore: number; // 0 - 100
  keyRisks: string[];
  recommendations: string[];
  dpiaRequired: boolean;
  dpiaJustification: string;
  legalBasis: string; // e.g. Consent, Legitimate Interests, Contractual Necessity
  euAiActClassification: 'Prohibited' | 'High-Risk' | 'Limited Risk' | 'Minimal Risk';
}

export interface AIProject {
  id: string;
  name: string;
  description: string;
  department: string;
  leadName: string;
  leadEmail: string;
  status: ProjectStatus;
  createdAt: string;
  updatedAt: string;
  answers: AssessmentAnswers;
  riskRating: RiskLevel;
  aiAnalysis: AIAnalysis | null;
  reviewerNotes: string;
  conditions: string[];
  signOffBy: string;
  signOffDate: string;
}
